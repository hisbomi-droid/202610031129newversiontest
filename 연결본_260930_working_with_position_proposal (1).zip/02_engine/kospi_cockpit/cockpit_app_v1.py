# -*- coding: utf-8 -*-
"""
cockpit_app_v1.py
=======================================================================
KOSPI 콕핏 대시보드 — ③패널 구성 (Streamlit)
=======================================================================
[배치 규칙] 02_engine/kospi_cockpit/cockpit_app_v1.py
[실행]      cd 02_engine && streamlit run kospi_cockpit/cockpit_app_v1.py
[수정빈도]   대시보드는 잦은 수정 대상 — 로직 수정 금지, 버전 분리 원칙(v1.1+)
[버전]       v1 (2026-10-02)

설계 확정 3패널:
  ① 콕핏 센서   : kospi_cockpit_sensor_hub_v1_1 (TIR/State-Space/Friction)
  ② 포지션 제안 : universal_quant_engine.strategies.proposal.position_proposal
  ③ Diff        : 이전 실행 스냅샷과 비교 — 변경된 항목만 표시
  (+ 예측 원장 신뢰도 요약)

원칙 (마스터 지시문 준수):
  - 본 대시보드는 "제안(proposal)"만 표시한다. 실매매·주문 실행 금지.
  - Diff 스냅샷(04_data/local/cockpit_last_run.json)은 Git에 커밋하지 않는다
    (SEC-402/403 — .gitignore에 04_data/local/ 패턴 추가).
  - 임의 계수 하드코딩 금지 — 포지션 제안 계수는 preset_v1_draft()만 사용
    (OOS 미검증 draft 표시를 그대로 노출).
  - 지표 엔진 교체 가능 원칙: 본 파일은 센서/제안 모듈의 "결과"만 소비하고
    내부 구현을 참조하지 않는다.

※ 정직한 한계: 분봉(실시간)은 UME가 미지원 → ②③은 일봉 기준,
  ① 콕핏 분봉은 mock(참고용)임을 화면에 명시한다.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
import streamlit as st

# --- 경로 설정: 02_engine 루트를 sys.path에 추가 (샌드박스 아님, 사용자 환경 기준) ---
ENGINE_ROOT = Path(__file__).resolve().parent.parent  # 02_engine/
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

SNAPSHOT_PATH = ENGINE_ROOT / "04_data" / "local" / "cockpit_last_run.json"

st.set_page_config(page_title="KOSPI 콕핏 v1", layout="wide")


# =====================================================================
# 0. 유틸
# =====================================================================

def safe_import():
    """주변 모듈 import — 하나가 없어도 대시보드가 죽지 않게 분리 시도."""
    mods: Dict[str, Any] = {}
    errs: Dict[str, str] = {}

    def _try(name: str, fn):
        try:
            mods[name] = fn()
        except Exception as e:  # ImportError 포함
            mods[name] = None
            errs[name] = f"{type(e).__name__}: {e}"

    _try("bridge", lambda: __import__("ume_daily_bridge"))
    _try("hub", lambda: __import__("kospi_cockpit_sensor_hub_v1_1"))
    _try("proposal", lambda: __import__(
        "universal_quant_engine.strategies.proposal.position_proposal",
        fromlist=["position_proposal"]))
    _try("ledger", lambda: __import__("prediction_ledger"))
    return mods, errs


def make_snapshot_key(df_daily: pd.DataFrame, fused: pd.DataFrame,
                      proposal_row: Optional[pd.Series]) -> Dict[str, Any]:
    """Diff 비교용 스냅샷 — '현재 상태'를 요약 키로 추출한다."""
    last = df_daily.iloc[-1]
    snap: Dict[str, Any] = {
        "data_date": str(pd.Timestamp(df_daily.index[-1]).date()),
        "close": float(last["close"]),
        "futures_is_proxy": bool(df_daily.attrs.get("FUTURES_IS_PROXY", False)),
        "trade_amount_is_proxy": bool(df_daily.attrs.get("TRADE_AMOUNT_IS_PROXY", False)),
    }
    if fused is not None and len(fused) > 0:
        fr = fused.iloc[-1]
        snap["tir_event"] = bool(fr.get("tir_event", False))
        snap["cascade_label"] = str(fr.get("cascade_label", ""))
        snap["regime_alert"] = bool(fr.get("regime_alert", False))
        snap["friction_spike"] = bool(fr.get("friction_spike", False))
    if proposal_row is not None:
        for k in ("regime", "action", "W", "validation_status", "position_status"):
            v = proposal_row.get(k, None)
            snap[f"proposal_{k}"] = None if v is None or (isinstance(v, float) and np.isnan(v)) else (
                float(v) if isinstance(v, (int, float, np.floating)) else str(v))
    return snap


def diff_snapshots(prev: Optional[Dict], curr: Dict) -> pd.DataFrame:
    """이전 스냅샷과 현재를 비교 — '바뀐 항목만' 반환. prev 없으면 전체 신규 표시."""
    rows = []
    keys = sorted(set(list(prev.keys()) + list(curr.keys())) if prev else curr.keys())
    for k in keys:
        old = None if prev is None else prev.get(k, "(신규)")
        new = curr.get(k, "(삭제)")
        if prev is None or old != new:
            rows.append({"항목": k, "이전": str(old), "현재": str(new)})
    if not rows:
        rows.append({"항목": "(변경 없음)", "이전": "-", "현재": "-"})
    return pd.DataFrame(rows)


def load_prev_snapshot() -> Optional[Dict]:
    if not SNAPSHOT_PATH.exists():
        return None
    try:
        return json.loads(SNAPSHOT_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        st.warning(f"이전 스냅샷 로드 실패(Diff 비교 불가): {e}")
        return None


def save_snapshot(snap: Dict) -> None:
    SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
    SNAPSHOT_PATH.write_text(json.dumps(snap, ensure_ascii=False, indent=2),
                             encoding="utf-8")


# =====================================================================
# 1. 패널 ① 콕핏 센서
# =====================================================================

def render_sensor_panel(hub_mod, bridge_mod, df_daily: pd.DataFrame) -> Optional[pd.DataFrame]:
    st.subheader("① 콕핏 센서 (TIR / State-Space / Friction)")
    st.caption("⚠️ 일봉=실제 UME 데이터, 분봉=mock(참고용) — 분봉 판단은 실매매 근거로 쓰지 말 것")
    if hub_mod is None or bridge_mod is None:
        st.error("센서허브/브릿지 모듈을 찾을 수 없습니다 (02_engine 배치 확인).")
        return None
    try:
        hub = hub_mod.KospiCockpitSensorHub()
        demo_date = df_daily.index[-1]
        df_intraday = hub_mod.generate_mock_intraday_bars(
            n_bars=500, start=f"{pd.Timestamp(demo_date).date()} 09:00")
        fused = hub.run(df_intraday, df_daily)

        last = fused.iloc[-1]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("tir_event (일봉)", "발생" if bool(last.get("tir_event", False)) else "없음")
        c2.metric("cascade_label", str(last.get("cascade_label", "-")))
        c3.metric("friction_spike", "ON" if bool(last.get("friction_spike", False)) else "OFF")
        c4.metric("regime_alert", "🚨" if bool(last.get("regime_alert", False)) else "-")

        st.caption("friction 엔진 상태: " + (
            "실제 연동" if getattr(hub.friction_adapter, "using_real_engine", False)
            else "폴백 PROXY (friction_engine.py 미연결)"))
        st.caption("TIR 엔진 상태: " + (
            "실제 v1 모듈" if getattr(hub.tir_sensor, "using_real_module", False)
            else "폴백 PROXY"))

        with st.expander("최근 센서 상세 (마지막 10개 분봉)"):
            cols = [c for c in ["tir_event", "Q_z", "friction_score", "friction_spike",
                                "x_t", "v_t", "a_t", "cascade_label"] if c in fused.columns]
            st.dataframe(fused[cols].tail(10))
        return fused
    except Exception as e:
        st.error(f"센서 계산 실패: {type(e).__name__}: {e}")
        return None


# =====================================================================
# 2. 패널 ② 포지션 제안
# =====================================================================

def render_proposal_panel(proposal_mod, df_daily: pd.DataFrame) -> Optional[pd.Series]:
    st.subheader("② 포지션 제안 (proposal — 실행 아님)")
    st.caption("계수 프리셋: preset_v1_draft() — OOS 미검증 draft. UNCALIBRATED 상태면 W=0으로 억제됨.")
    if proposal_mod is None:
        st.error("position_proposal 모듈 import 실패 "
                 "(02_engine/universal_quant_engine/strategies/proposal/ 배치 확인).")
        return None

    # --- 진입점 후보 탐색: 모듈 함수명은 버전에 따라 달라질 수 있어 방어적으로 탐색 ---
    entry = None
    for name in ("compute_position_proposal", "compute_proposal", "run_proposal", "propose"):
        fn = getattr(proposal_mod, name, None)
        if callable(fn):
            entry = fn
            st.caption(f"진입점: position_proposal.{name}()")
            break
    preset = getattr(proposal_mod, "preset_v1_draft", None)

    if entry is None:
        st.error("position_proposal에 진입 함수(compute_position_proposal 등)가 없습니다. "
                 "모듈 버전 확인 후 어댑터 수정 필요.")
        return None
    try:
        cfg = preset() if callable(preset) else None
        out = entry(df_daily, config=cfg) if cfg is not None else entry(df_daily)
        if not isinstance(out, pd.DataFrame) or len(out) == 0:
            st.warning("포지션 제안 결과가 비어 있습니다.")
            return None
        row = out.iloc[-1]

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("regime", str(row.get("regime", "-")))
        c2.metric("action", str(row.get("action", "-")))
        w = row.get("W", None)
        c3.metric("W", f"{float(w):+.2f}" if w is not None and not pd.isna(w) else "-")
        c4.metric("validation_status", str(row.get("validation_status", "-")))

        vs = str(row.get("validation_status", ""))
        if vs == "UNCALIBRATED":
            st.warning("계수 미확정(UNCALIBRATED) — W=0 억제 상태. 실매매 연결 금지.")
        if str(row.get("position_status", "")) == "BUFFER_HOLD":
            st.info("rebalance_buffer 내 변동 — 포지션 유지(BUFFER_HOLD).")

        if "reasons" in out.columns:
            reasons = out.iloc[-1].get("reasons")
            if reasons:
                with st.expander("F_net 근거 (reasons)"):
                    st.write(reasons if not isinstance(reasons, str) else [reasons])
        return row
    except Exception as e:
        st.error(f"포지션 제안 계산 실패: {type(e).__name__}: {e}")
        return None


# =====================================================================
# 3. 패널 ③ Diff (이전 실행 대비 변경)
# =====================================================================

def render_diff_panel(prev: Optional[Dict], curr: Dict) -> None:
    st.subheader("③ 이전 결과 대비 변경 (Diff)")
    if prev is None:
        st.info("이전 스냅샷 없음 — 이번 실행 기준으로 저장됩니다. 다음 실행부터 Diff가 표시됩니다.")
    st.dataframe(diff_snapshots(prev, curr), use_container_width=True)
    if st.button("이번 결과를 스냅샷으로 저장"):
        save_snapshot(curr)
        st.success(f"저장 완료 → Git 미커밋 경로(04_data/local/). 다음 실행 시 Diff 기준이 됩니다.")


# =====================================================================
# 4. 패널 ④ 예측 원장 신뢰도 요약
# =====================================================================

def render_ledger_panel(ledger_mod) -> None:
    st.subheader("④ 예측 원장 신뢰도 (OOS)")
    if ledger_mod is None:
        st.info("prediction_ledger 모듈 없음 — 패널 비활성화.")
        return
    st.caption("판정 기준: n>=30 AND Wilson 95% CI 하한>50% → VERIFIED")
    st.info("원장은 실행 간 누적 파일(04_data/local/*.jsonl)을 사용합니다. "
            "이 패널은 저장된 원장이 있을 때만 요약을 표시합니다.")
    try:
        ledger = ledger_mod.PredictionLedger()
        found = False
        for p in sorted((ENGINE_ROOT / "04_data" / "local").glob("*ledger*.jsonl")):
            ledger = ledger_mod.PredictionLedger()
            ledger.load(str(p), legacy_symbol="KOSPI")
            if ledger.records:
                found = True
                with st.expander(f"{p.name} — {len(ledger.records)}건"):
                    s1 = ledger_mod.OOSAnalyzer().summarize(ledger)
                    s2 = ledger_mod.OOSAnalyzer().summarize_binary_events(ledger)
                    if not s1.empty:
                        st.dataframe(s1)
                    if not s2.empty:
                        st.dataframe(s2)
        if not found:
            st.write("저장된 원장이 없습니다 (run_real_daily_demo.py 등에서 save() 후 표시됨).")
    except Exception as e:
        st.warning(f"원장 요약 실패: {type(e).__name__}: {e}")


# =====================================================================
# 5. 메인
# =====================================================================

def main() -> None:
    st.title("🛩️ KOSPI 콕핏 v1")
    st.caption("수집 → 지표 → 센서 → 포지션 제안 → Diff → 예측 검증 (제안만 표시, 실매매 아님)")

    mods, errs = safe_import()
    if errs:
        with st.expander("모듈 import 상태"):
            for k, v in errs.items():
                st.write(f"- `{k}`: {v}")

    # --- 데이터 수집 (① 브릿지 → 표준 일봉) ---
    st.sidebar.header("데이터")
    count = st.sidebar.slider("일봉 개수", 100, 500, 250, step=50)
    if st.sidebar.button("데이터 새로 수집"):
        st.cache_data.clear()
    df_daily = None
    if mods["bridge"] is None:
        st.error("ume_daily_bridge를 찾을 수 없습니다.")
        st.stop()
    try:
        df_daily = load_cached_daily(mods["bridge"], count)
    except Exception as e:
        st.error(f"일봉 수집 실패: {e}")
        st.stop()
    if df_daily is None or df_daily.empty:
        st.error("수집 결과가 비어 있습니다.")
        st.stop()

    st.sidebar.caption(
        f"데이터: {pd.Timestamp(df_daily.index[0]).date()} ~ "
        f"{pd.Timestamp(df_daily.index[-1]).date()} ({len(df_daily)}개)")
    if df_daily.attrs.get("FUTURES_IS_PROXY"):
        st.sidebar.warning("futures_close = KOSPI200 현물 근사")
    if df_daily.attrs.get("TRADE_AMOUNT_IS_PROXY"):
        st.sidebar.warning("trade_amount = 종가×거래량 근사")

    prev = load_prev_snapshot()

    # --- 패널 렌더 ---
    fused = render_sensor_panel(mods["hub"], mods["bridge"], df_daily)
    proposal_row = render_proposal_panel(mods["proposal"], df_daily)

    curr = make_snapshot_key(df_daily, fused if fused is not None else pd.DataFrame(), proposal_row)
    render_diff_panel(prev, curr)

    render_ledger_panel(mods["ledger"])

    st.divider()
    st.caption("※ 본 화면의 모든 포지션/W 값은 제안(proposal)이며 실주문 실행 기능은 없습니다.")


@st.cache_data(show_spinner="UME에서 일봉 수집 중 (KRX→네이버→야후 폴백)...")
def load_cached_daily(_bridge_mod, count: int):
    """캐시된 일봉 로드 — bridge 모듈은 캐시 키로 쓸 수 없어 문자열로 대체한다."""
    return load_cached_daily_inner(count)


def load_cached_daily_inner(count: int):
    from ume_daily_bridge import load_daily_from_ume
    return load_daily_from_ume(count=count)


if __name__ == "__main__":
    main()