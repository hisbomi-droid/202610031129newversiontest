"""Position proposal strategy package."""
