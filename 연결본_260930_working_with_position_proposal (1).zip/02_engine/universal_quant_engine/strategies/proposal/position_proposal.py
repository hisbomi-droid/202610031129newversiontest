# -*- coding: utf-8 -*-
"""
position_proposal.py
=======================================================================
UME(Universal Quant Engine) 자립형 매매 제안(position proposal) 모듈
— mfe_v2.position L13~L15 계약 계승, UME 패키지 의존 없음
=======================================================================
[배치 규칙] 02_engine/universal_quant_engine/strategies/proposal/position_proposal.py
            같은 폴더에 __init__.py 필요 (아래 별도 전달)
[실행]      cd 02_engine && python -m universal_quant_engine.strategies.proposal.position_proposal
[수정빈도]   전략 로직 — 잦은 수정 대상. 로직 수정 시 버전 분리(v1.1+)
[버전]       v1 (2026-10-02)

계약 요약:
  - 입력: 표준 OHLCV DataFrame (DatetimeIndex, 컬럼: high/low/close/volume;
          volume이 없으면 volume 성분은 계산하지 않고 그대로 진행)
  - regime 판정: ADX/DI 강도 -> breakout / Bollinger sigma -> regression /
      ATR 수축 -> absorption / 나머지 neutral; 워밍업 구간은 unconfirmed
  - F_net: trend/momentum/volume 성분을 z-표준화 후 합성 (각 근거는 reasons에 보존)
  - L13: F_z = rolling z-score, 크기 정규화 전용. 방향은 반드시 sign(F_net)
  - L15: rebalance_buffer — 방향 반전(|W_new - W_old| >= buffer)은 항상 통과
  - 계수(coefficient)가 하나라도 None이면 UNCALIBRATED + W=0 (계산 억제)
  - 출력은 제안(proposal)일 뿐, 실매매·주문 실행 아님 (마스터 지시문)

상태 어휘:
  validation_status: OK / UNCALIBRATED / INPUT_NAN / INPUT_INVALID /
                     REGIME_UNCONFIRMED / F_NET_ZERO
  position_status:   UPDATED / BUFFER_HOLD / REGIME_FLAT / NO_PROPOSAL
  action:            LONG / SHORT / FLAT
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd


# =====================================================================
# 0. 계수 정의 — 임의 계수 하드코딩 금지, 전부 기본 None
# =====================================================================

@dataclass
class ProposalCoefficients:
    # --- regime 판정 ---
    adx_breakout: Optional[float] = None       # ADX 이상 값 -> breakout 후보
    di_gap_min: Optional[float] = None         # +DI - -DI 최소 격차
    bb_reversion_sigma: Optional[float] = None # 종가가 밴드 밖 |z| 기준
    atr_shrink_window: Optional[int] = None    # ATR 수축 비교 윈도우
    atr_shrink_ratio: Optional[float] = None   # ATR_short/ATR_long <= ratio -> absorption

    # --- F_net 표준화 ---
    fnet_z_window: Optional[int] = None        # trend/momentum 성분 rolling z 윈도우
    volume_z_window: Optional[int] = None      # volume 성분 rolling z 윈도우

    # --- L13 크기/스케일 ---
    theta_force: Optional[float] = None        # F_net 자기 자체 스케일 (mfe_v2 계약)
    force_z_window: Optional[int] = None       # F_z rolling z-score 윈도우
    breakout_scale: Optional[float] = None     # breakout 국면 W 스케일 cap
    max_reversion_scale: Optional[float] = None  # regression/absorption 최대 스케일

    # --- L15 buffer ---
    rebalance_buffer: Optional[float] = None   # |W_new - W_prev| < buffer -> 유지

    def is_calibrated(self) -> bool:
        """모든 필수 계수가 설정되어 있어야 True (하나라도 None이면 억제)."""
        return all(v is not None for v in (
            self.adx_breakout, self.di_gap_min, self.bb_reversion_sigma,
            self.atr_shrink_window, self.atr_shrink_ratio,
            self.fnet_z_window, self.volume_z_window,
            self.theta_force, self.force_z_window,
            self.breakout_scale, self.max_reversion_scale,
            self.rebalance_buffer))


def preset_v1_draft() -> ProposalCoefficients:
    """v1 draft 프리셋 — OOS(아웃오브샘플) 미검증. 실매매 연결 금지 표기용."""
    return ProposalCoefficients(
        adx_breakout=25.0, di_gap_min=3.0,
        bb_reversion_sigma=2.0,
        atr_shrink_window=20, atr_shrink_ratio=0.7,
        fnet_z_window=60, volume_z_window=60,
        theta_force=1.0, force_z_window=60,
        breakout_scale=0.8, max_reversion_scale=0.3,
        rebalance_buffer=0.10,
    )


# =====================================================================
# 1. 지표 (전부 causal — rolling은 t시점까지 값만 사용, shift(-) 금지)
# =====================================================================

def _rolling_z(s: pd.Series, window: int) -> pd.Series:
    m = s.rolling(window, min_periods=window).mean()
    sd = s.rolling(window, min_periods=window).std()
    return (s - m) / sd.replace(0, np.nan)


def compute_indicators(df: pd.DataFrame, atr_window: int = 14,
                       adx_window: int = 14, bb_window: int = 20) -> pd.DataFrame:
    out = df.copy()
    prev_close = out["close"].shift(1)
    tr = pd.concat([out["high"] - out["low"],
                    (out["high"] - prev_close).abs(),
                    (out["low"] - prev_close).abs()], axis=1).max(axis=1)
    out["ATR"] = tr.rolling(atr_window, min_periods=atr_window).mean()

    # ADX / DI
    up = out["high"].diff()
    dn = -out["low"].diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=out.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=out.index)
    atr14 = out["ATR"].replace(0, np.nan)
    plus_di = 100 * (plus_dm.rolling(adx_window, min_periods=adx_window).mean() / atr14)
    minus_di = 100 * (minus_dm.rolling(adx_window, min_periods=adx_window).mean() / atr14)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    out["ADX"] = dx.rolling(adx_window, min_periods=adx_window).mean()
    out["DI_plus"] = plus_di
    out["DI_minus"] = minus_di

    # Bollinger
    ma = out["close"].rolling(bb_window, min_periods=bb_window).mean()
    sd = out["close"].rolling(bb_window, min_periods=bb_window).std()
    out["BB_z"] = (out["close"] - ma) / sd.replace(0, np.nan)

    # 성분 원료
    out["mom_raw"] = out["close"].pct_change()
    out["trend_raw"] = out["close"] - out["close"].rolling(bb_window, min_periods=bb_window).mean()
    if "volume" in out.columns:
        out["vol_raw"] = out["volume"].pct_change()
    return out


# =====================================================================
# 2. Regime 판정
# =====================================================================

def classify_regime(ind: pd.DataFrame, cfg: ProposalCoefficients) -> pd.Series:
    """ADX/DI->breakout, BB sigma->regression, ATR 수축->absorption,
    나머지 neutral. 워밍업(NaN)은 unconfirmed."""
    n = len(ind)
    regimes: List[str] = []
    for i in range(n):
        row = ind.iloc[i]
        adx, bbz = row.get("ADX"), row.get("BB_z")
        di_gap = row.get("DI_plus") - row.get("DI_minus")
        atr = row.get("ATR")
        atr_long = ind["ATR"].iloc[max(0, i - cfg.atr_shrink_window):i + 1]
        if any(pd.isna(x) for x in (adx, bbz, di_gap)) or pd.isna(atr):
            regimes.append("unconfirmed")
            continue
        if adx >= cfg.adx_breakout and abs(di_gap) >= cfg.di_gap_min:
            regimes.append("breakout")
        elif abs(bbz) >= cfg.bb_reversion_sigma:
            regimes.append("regression")
        elif (len(atr_long) >= cfg.atr_shrink_window and not atr_long.isna().any()
              and atr <= atr_long.mean() * cfg.atr_shrink_ratio):
            regimes.append("absorption")
        else:
            regimes.append("neutral")
    return pd.Series(regimes, index=ind.index, name="regime")


# =====================================================================
# 3. F_net 합성 (성분 z-표준화, reasons 보존)
# =====================================================================

def compute_f_net(ind: pd.DataFrame, cfg: ProposalCoefficients) -> pd.DataFrame:
    out = ind.copy()
    reasons: List[Optional[List[str]]] = []
    f_net = pd.Series(0.0, index=out.index)

    trend_z = _rolling_z(out["trend_raw"], cfg.fnet_z_window)
    mom_z = _rolling_z(out["mom_raw"], cfg.fnet_z_window)
    vol_z = (_rolling_z(out["vol_raw"], cfg.volume_z_window)
             if "vol_raw" in out.columns else pd.Series(np.nan, index=out.index))

    for i in range(len(out)):
        r: List[str] = []
        total = 0.0
        for name, comp in (("trend", trend_z), ("momentum", mom_z), ("volume", vol_z)):
            v = comp.iloc[i]
            if not pd.isna(v):
                total += float(v)
                r.append(f"{name}={v:+.2f}")
        if not r:
            r = None
        reasons.append(r)
        f_net.iloc[i] = total * cfg.theta_force if r else np.nan
    out["F_net"] = f_net
    out["reasons"] = reasons
    return out


# =====================================================================
# 4. L13~L15: F_z -> W 산출 (buffer 포함)
# =====================================================================

def compute_position_proposal(df: pd.DataFrame,
                              config: Optional[ProposalCoefficients] = None
                              ) -> pd.DataFrame:
    """메인 진입점. df: 표준 OHLCV (DatetimeIndex). 반환: 제안 DataFrame."""
    cfg = config or ProposalCoefficients()
    required = {"high", "low", "close"}
    if not required <= set(df.columns):
        raise ValueError(f"INPUT_INVALID: 필수 컬럼 누락 - {sorted(required - set(df.columns))}")
    if not isinstance(df.index, pd.DatetimeIndex):
        raise ValueError("INPUT_INVALID: DatetimeIndex 필요 (ume_daily_bridge 출력 사용 권장)")

    ind = compute_indicators(df.copy())

    # --- 계수 미확정: 전 구간 억제 (UNCALIBRATED, W=0) ---
    if not cfg.is_calibrated():
        n = len(ind)
        return pd.DataFrame({
            "regime": "unconfirmed",
            "F_net": np.nan,
            "F_z": np.nan,
            "W": 0.0,
            "W_prev": 0.0,
            "action": "FLAT",
            "validation_status": "UNCALIBRATED",
            "position_status": "NO_PROPOSAL",
            "reasons": [[None] for _ in range(n)],
        }, index=df.index)

    if ind[["close"]].isna().any().any():
        st = "INPUT_NAN"
    else:
        st = "OK"

    ind["regime"] = classify_regime(ind, cfg)
    ind = compute_f_net(ind, cfg)

    f_z = _rolling_z(ind["F_net"], cfg.force_z_window)
    ind["F_z"] = f_z

    rows_w, rows_act, rows_vs, rows_ps = [], [], [], []
    w_prev = 0.0
    for i in range(len(ind)):
        row = ind.iloc[i]
        regime = row["regime"]

        if st != "OK":
            rows_vs.append(st); rows_ps.append("NO_PROPOSAL")
            rows_w.append(0.0); rows_act.append("FLAT")
            w_prev = 0.0
            continue
        if regime == "unconfirmed":
            rows_vs.append("REGIME_UNCONFIRMED"); rows_ps.append("REGIME_FLAT")
            rows_w.append(0.0); rows_act.append("FLAT")
            w_prev = 0.0
            continue
        fn, fz = row["F_net"], row["F_z"]
        if pd.isna(fn) or pd.isna(fz) or fn == 0:
            rows_vs.append("F_NET_ZERO" if not (pd.isna(fn) or pd.isna(fz)) else st)
            rows_ps.append("NO_PROPOSAL")
            rows_w.append(0.0); rows_act.append("FLAT")
            w_prev = 0.0
            continue

        # L13: 방향 = sign(F_net) 유일, 크기 = |F_z| 스케일 (regime cap)
        direction = 1.0 if fn > 0 else -1.0
        if regime == "breakout":
            scale = cfg.breakout_scale
        else:  # regression / absorption / neutral
            scale = cfg.max_reversion_scale
        w_new = float(np.clip(direction * min(abs(fz), 3.0) / 3.0 * scale, -1.0, 1.0))

        # L15: buffer — 방향 반전(|ΔW| 대칭 아님, 부호 반전)은 항상 통과
        reversed_dir = (w_new * w_prev < 0)
        if reversed_dir or abs(w_new - w_prev) >= cfg.rebalance_buffer:
            rows_ps.append("UPDATED")
            w_prev = w_new
        else:
            rows_ps.append("BUFFER_HOLD")
            w_new = w_prev
        rows_w.append(w_new)
        rows_act.append("LONG" if w_new > 0 else "SHORT" if w_new < 0 else "FLAT")
        rows_vs.append("OK")

    ind["W"] = rows_w
    ind["action"] = rows_act
    ind["validation_status"] = rows_vs
    ind["position_status"] = rows_ps
    return ind[["regime", "F_net", "F_z", "W", "action",
                "validation_status", "position_status", "reasons",
                "ADX", "BB_z", "ATR"]]


# =====================================================================
# 5. 단위 테스트 (7개)
# =====================================================================

def _mock_df(n=200, seed=7, drift=0.0, vol=0.01) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2025-01-02", periods=n)
    ret = rng.normal(drift, vol, n)
    close = 2500 * np.exp(np.cumsum(ret))
    high = close * (1 + rng.uniform(0.001, 0.004, n))
    low = close * (1 - rng.uniform(0.001, 0.004, n))
    volume = rng.normal(1e6, 2e5, n).clip(min=1e4)
    return pd.DataFrame({"high": high, "low": low, "close": close,
                         "volume": volume}, index=idx)


def _run_tests() -> int:
    results = []

    def check(name, cond):
        results.append(bool(cond))
        print(f"{'PASS' if cond else 'FAIL'} - {name}")

    cfg = preset_v1_draft()
    df = _mock_df(250)

    # T1: 계수 미확정 -> 전 구간 W=0 + UNCALIBRATED (계산 억제)
    out0 = compute_position_proposal(df, ProposalCoefficients())
    check("T1 미확정 계수 -> UNCALIBRATED & W=0 전 구간 억제",
          (out0["validation_status"] == "UNCALIBRATED").all()
          and (out0["W"] == 0).all())

    out = compute_position_proposal(df, cfg)
    check("T2 캘리브레이션 시 OK/REGIME_* 상태만 존재",
          set(out["validation_status"]) <= {"OK", "REGIME_UNCONFIRMED",
                                            "F_NET_ZERO", "INPUT_NAN"})

    # T3: 워밍업(unconfirmed) 구간은 W=0 (regime 청산)
    warm = out.iloc[:60]
    check("T3 워밍업 구간 regime 청산 (W=0)",
          (warm.loc[warm["regime"] == "unconfirmed", "W"] == 0).all())

    # T4: 방향은 반드시 sign(F_net)과 일치 (W=0 제외)
    m = (out["W"] != 0) & out["F_net"].notna()
    check("T4 방향 = sign(F_net) 유일 위반 없음",
          (np.sign(out.loc[m, "W"]) == np.sign(out.loc[m, "F_net"])).all())

    # T5: buffer — |ΔW| < buffer & 동일 방향이면 BUFFER_HOLD
    dw = out["W"].diff().abs().fillna(0)
    hold = out["position_status"] == "BUFFER_HOLD"
    if hold.any():
        check("T5 BUFFER_HOLD 구간 |ΔW| < buffer",
              (dw[hold] < cfg.rebalance_buffer).all())
    else:
        check("T5 BUFFER_HOLD 미발생 (정상)", True)

    # T6: rolling std=0 -> F_z NaN -> NO_PROPOSAL 크래시 없음
    df_flat = df.copy(); df_flat.loc[df.index, "close"] = 2500.0
    out_flat = compute_position_proposal(df_flat, cfg)
    check("T6 std=0/NaN 입력 -> 크래시 없음", len(out_flat) == len(df_flat))

    # T7: 방향 반전은 buffer와 무관하게 항상 스위칭
    rev = (out["W"].shift(1).fillna(0) * out["W"]) < 0
    if rev.any():
        check("T7 방향 반전 시 UPDATED (즉시 스위칭)",
              (out.loc[rev, "position_status"] == "UPDATED").all())
    else:
        check("T7 반전 미발생 (정상)", True)

    print(f"\n{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(_run_tests())