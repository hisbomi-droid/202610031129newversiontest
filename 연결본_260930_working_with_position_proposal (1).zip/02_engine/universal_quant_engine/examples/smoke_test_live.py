"""실제 연결 점검 — 수집기를 하나씩 따로 호출해 어디서 막히는지 보여준다.

실행 (인터넷 필요, KRX는 KRX_AUTH_KEY 환경변수 필요):
    cd 02_engine
    export KRX_AUTH_KEY=발급받은키          # Windows: set KRX_AUTH_KEY=발급받은키
    python universal_quant_engine/examples/smoke_test_live.py

※ KRX는 처음 실행 시 하루 단위 요청(요청 간 1초)이라 수 분 걸릴 수 있다. 캐시가 쌓이면 빨라진다.
   KRX가 오래 걸리면 인자로 봉 수를 줄여라:  python ... 20
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

from universal_quant_engine import Market  # noqa: E402


def main(count: int = 30) -> int:
    fails = 0
    for name in ("krx", "naver", "yahoo"):
        t0 = time.time()
        try:
            m = Market(providers=[name], fetch_mode="fallback")
            df = m.market("KOSPI", count=count)
            v = m.validator.validate(df)
            print(f"[OK ] {name:6s} {len(df):3d}봉  마지막={df['timestamp'].iloc[-1]:%Y-%m-%d}  "
                  f"종가={df['close'].iloc[-1]:,.2f}  검증={'통과' if v['passed'] else '실패'}  "
                  f"상태={m.last_report['status'][name]}  ({time.time() - t0:.1f}초)")
        except Exception as exc:
            fails += 1
            print(f"[FAIL] {name:6s} {exc}")
    print("\n폴백 체인 (krx → naver → yahoo):")
    try:
        m = Market(providers=["krx", "naver", "yahoo"], fetch_mode="fallback")
        m.market("KOSPI", count=count)
        print(f"  사용된 소스: {m.last_report['used']}  실패 기록: {m.last_report['errors']}")
    except Exception as exc:
        fails += 1
        print(f"  전체 실패: {exc}")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(int(sys.argv[1]) if len(sys.argv) > 1 else 30))
