"""연결 테스트 — UME(가짜 응답) → ume_daily_bridge → TIR/센서허브/원장까지 끝까지 돈다.

실행: cd 02_engine && python test_connection_v1.py
"""
import sys
from datetime import date, datetime, timedelta

sys.path.insert(0, ".")

from universal_quant_engine.collectors import _common  # noqa: E402


class FakeResp:
    def __init__(self, obj):
        import json
        self._raw = json.dumps(obj).encode("utf-8")

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def naver_rows_for(base_close, n=260):
    return [{"localDate": (date(2025, 1, 2) + timedelta(days=i)).strftime("%Y%m%d"),
             "openPrice": base_close + i * 0.3, "highPrice": base_close + i * 0.3 + 15,
             "lowPrice": base_close + i * 0.3 - 15, "closePrice": base_close + i * 0.3 + 5,
             "accumulatedTradingVolume": 400_000 + i * 100} for i in range(n)]


def fake_handler(url, headers):
    if "KOSPI200" in url or "index/KOSPI200" in url:
        return {"priceInfos": naver_rows_for(330.0)}
    return {"priceInfos": naver_rows_for(2500.0)}


def install_fake():
    def fake_urlopen(req, timeout=None):
        return FakeResp(fake_handler(req.full_url, dict(req.header_items())))
    _common.urlopen = fake_urlopen


def run():
    results = []

    def check(name, cond):
        results.append(bool(cond))
        print(f"{'PASS' if cond else 'FAIL'} - {name}")

    install_fake()
    from ume_daily_bridge import load_daily_from_ume
    df_daily = load_daily_from_ume(providers=["naver"], count=260)
    check("브릿지: 필요 컬럼 모두 존재",
          {"spot_close", "futures_close", "high", "low", "close", "trade_amount"} <= set(df_daily.columns))
    check("브릿지: 근사치 플래그 표시됨",
          df_daily.attrs.get("FUTURES_IS_PROXY") and df_daily.attrs.get("TRADE_AMOUNT_IS_PROXY"))
    check("브릿지: 코스피/코스피200 섞이지 않음(스케일 다름)",
          df_daily["spot_close"].mean() > df_daily["futures_close"].mean() * 2)

    import tir_reflection_backtest_v1 as tir
    tir_df = tir.run_backtest_v1(df_daily)
    check("TIR: 실제(가짜응답) 일봉으로 tir_signal 컬럼 생성", "tir_signal" in tir_df.columns)

    import prediction_ledger as _pl
    ledger = _pl.PredictionLedger()
    added = tir.record_tir_predictions(tir_df, ledger)
    check("TIR→원장: 신호 있으면 기록, 없어도 예외 없음", added >= 0)

    from kospi_cockpit_sensor_hub_v1_1 import KospiCockpitSensorHub, generate_mock_intraday_bars
    hub = KospiCockpitSensorHub()
    demo_date = df_daily.index[-1]
    df_intraday = generate_mock_intraday_bars(n_bars=300, start=f"{demo_date.date()} 09:00")
    result = hub.run(df_intraday, df_daily)
    check("센서허브: 실제(가짜응답) 일봉 + mock 분봉으로 끝까지 실행",
          "regime_alert" in result.columns and len(result) == len(df_intraday))

    print("\n" + "=" * 50)
    print(f"{sum(results)}/{len(results)} 통과")
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(run())
