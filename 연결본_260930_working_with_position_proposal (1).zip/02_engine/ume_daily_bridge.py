"""UME 수집 모듈 ↔ 신뢰도검증 모듈(TIR/센서허브) 연결 어댑터.

tir_reflection_backtest_v1.load_market_data() 및 kospi_cockpit_sensor_hub.run()의
df_daily 가 요구하는 형식(spot_close, futures_close, high, low, close, trade_amount)을
UME Market()이 주는 표준 OHLCV로부터 만들어낸다.

※ 정직하게 밝혀둘 근사치 2곳 (실제 숫자가 아님):
  1) futures_close : 실제 코스피200 선물 가격이 아니라 코스피200 "현물" 지수로 대신함
     (UME에 선물 데이터 소스가 없음). theta_proxy(베이시스)가 실제 선물-현물
     베이시스가 아니라 "코스피 - 코스피200" 차이로 계산된다는 뜻 → 정량적 의미 다름.
  2) trade_amount : 실제 거래대금(원화 금액)이 아니라 거래량×종가로 근사.
     KRX OutBlock_1에 거래대금 필드가 없어 생기는 근사.

둘 다 FUTURES_IS_PROXY / TRADE_AMOUNT_IS_PROXY 플래그를 DataFrame.attrs에 남긴다.
정밀하게 맞추려면: futures_close는 KRX 선물 API(별도 엔드포인트) 추가, trade_amount는
KRX OutBlock_1의 실제 거래대금 필드(있다면) 매핑이 필요 — 둘 다 2차 작업.
"""
from typing import List, Optional

import pandas as pd

from universal_quant_engine import Market


def load_daily_from_ume(spot_symbol: str = "KOSPI", futures_proxy_symbol: str = "KOSPI200",
                        count: int = 250, providers: Optional[List[str]] = None,
                        fetch_mode: str = "fallback", provider_kwargs: Optional[dict] = None
                        ) -> pd.DataFrame:
    """tir_reflection_backtest_v1 / kospi_cockpit_sensor_hub 의 df_daily 형식으로 반환.

    실패 시 조용히 넘어가지 않고 RuntimeError를 그대로 올린다(원인은 UME의
    market()이 last_report에 담아 예외 메시지에 포함시킴).
    """
    m = Market(providers=providers or ["krx", "naver", "yahoo"],
              fetch_mode=fetch_mode, provider_kwargs=provider_kwargs or {})
    spot = m.market(spot_symbol, count=count)
    spot_report = dict(m.last_report)  # futures 호출로 last_report가 덮이기 전에 보존
    fut = m.market(futures_proxy_symbol, count=count)

    spot = spot.set_index("timestamp")[["high", "low", "close", "volume"]]
    fut_close = fut.set_index("timestamp")["close"].rename("futures_close")

    # merge_asof(backward): 코스피200 쪽에 결측일이 있어도 미래 값이 새어들지 않게
    left = spot.reset_index().sort_values("timestamp")
    right = fut_close.reset_index().sort_values("timestamp")
    merged = pd.merge_asof(left, right, on="timestamp", direction="backward")
    merged = merged.dropna(subset=["futures_close"]).set_index("timestamp")

    out = pd.DataFrame({
        "spot_close": merged["close"],
        "futures_close": merged["futures_close"],
        "high": merged["high"],
        "low": merged["low"],
        "close": merged["close"],
        "trade_amount": merged["close"] * merged["volume"],
    })
    out.index.name = None  # generate_mock_daily_bars()와 동일한 무명 인덱스로 맞춤
                           # (KospiCockpitSensorHub.gate.fuse가 reset_index() 시
                           #  'index' 컬럼명을 기대하므로, 이름이 남아있으면 깨짐)
    out.attrs["FUTURES_IS_PROXY"] = True   # 실제 선물가 아님 (코스피200 현물로 대체)
    out.attrs["TRADE_AMOUNT_IS_PROXY"] = True  # 실제 거래대금 아님 (종가×거래량 근사)
    out.attrs["ume_report"] = {"spot": spot_report, "futures_proxy": dict(m.last_report)}
    return out
